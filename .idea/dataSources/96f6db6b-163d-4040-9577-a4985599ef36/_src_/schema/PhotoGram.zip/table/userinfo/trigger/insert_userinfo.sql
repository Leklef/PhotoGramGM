CREATE TRIGGER `insert_userinfo`
AFTER INSERT ON `userinfo`
FOR EACH ROW
  BEGIN
INSERT INTO backup_userinfo SET user_id=new.id, name=new.name, username=new.username, email=new.email;
END