CREATE TRIGGER `insert_userpassword`
AFTER INSERT ON `password_tables`
FOR EACH ROW
  BEGIN
INSERT INTO backup_password SET user_id=new.user_id, password=new.password;
END