CREATE PROCEDURE `search_user`(`nickname` VARCHAR(50))
  BEGIN
SELECT username FROM userinfo WHERE username LIKE concat(nickname,'%');
END