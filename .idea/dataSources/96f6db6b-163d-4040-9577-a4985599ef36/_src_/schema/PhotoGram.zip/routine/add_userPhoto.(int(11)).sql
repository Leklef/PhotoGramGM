CREATE PROCEDURE `add_userPhoto`(`id` INT(11))
  BEGIN
insert into userPhoto values (id, '/resources/img/123.png');
END