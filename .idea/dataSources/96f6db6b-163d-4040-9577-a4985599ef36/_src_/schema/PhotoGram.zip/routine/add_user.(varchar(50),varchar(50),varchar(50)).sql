CREATE PROCEDURE `add_user`(`name` VARCHAR(50), `username` VARCHAR(50), `email` VARCHAR(50))
  BEGIN
insert into userinfo values (default, name, username, email);
END